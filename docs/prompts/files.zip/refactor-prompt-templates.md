# 5 Refactor Prompt Templates

Copy-paste templates for driving a coding agent (or Claude Code session) through
high-leverage refactors. Each one follows the same discipline: **baseline first,
smallest reversible steps, tests green after every step, measurable outcome.**
Fill the `{{placeholders}}`, delete sections that don't apply.

---

## Template 1 — De-Engineering Pass (kill accidental complexity)

```
ROLE
You are a senior engineer performing a de-engineering pass. Your goal is to
reduce accidental complexity while preserving essential complexity and exact
behavior.

SCOPE
Target: {{package/directory/feature, e.g. services/billing}}
Out of scope: {{anything you must not touch, e.g. public API contracts, DB schema}}

BASELINE (do this before any edit)
1. Run the test suite for the target and record exact pass/fail state and duration.
2. Measure: LOC, file count, dependency edges in/out, max indirection depth
   (hops from entry point to behavior), duplicated logic.

HUNT FOR (classify every finding)
- Speculative generality: interfaces with one implementation, plugin systems
  with one plugin, config nothing flips, "future-proofing" never used.
- Indirection theater: factories of factories, event buses for synchronous
  local calls, DI ceremony around pure functions.
- Dead code: unused exports, unreachable branches, commented-out blocks.
- Duplication in disguise: near-identical logic diverging across files.
- Essential complexity: genuinely hard domain logic — FLAG IT, do not touch it
  except naming and tests.

TRANSFORMATION PREFERENCE (strict order)
delete > inline > merge > move > rewrite. Rewriting is the last resort.

RULES
- One transformation per commit. Tests must pass after every commit.
- Anything without test coverage: write a characterization test FIRST, then
  simplify, then keep the test.
- Never remove a guard/branch with a comment citing an incident or edge case
  without investigating it.
- If a step fails tests, revert that step cleanly — never stack fixes on a
  broken intermediate state.

DELIVERABLE
- Before/after metrics table (LOC, files, dep edges, indirection depth, test time).
- Ordered list of transformations with one-line justification each.
- List of essential-complexity zones you deliberately left alone and why.
- Anything you recommend removing but couldn't prove safe (with the evidence gap).
```

---

## Template 2 — Module Boundaries & Dependency Direction (maintainability)

```
ROLE
You are restructuring module boundaries in a large codebase so that change
cost becomes local and predictable.

SCOPE
Target: {{repo or subtree}}
Build system: {{Nx/Turbo/Bazel/Pants/plain — or say "detect it"}}

BASELINE
1. Generate the current dependency graph between packages/modules.
2. List: every cyclic dependency, every deep import that bypasses a public
   entry point, every package that changes for more than one unrelated reason,
   and every "utils/shared/common/helpers" dumping ground with its contents.

TARGET ARCHITECTURE
- Dependency direction: domain logic depends on nothing; adapters depend on
  domain; the composition root wires everything. Package cycles are P0 — break
  them first.
- Each package exposes a deliberate public API (entry point or build-visibility
  rule); everything else is internal. Fix deep imports as you go.
- Locality of behavior: functions live next to their primary caller or their
  data. Audit shared/utils for squatters and relocate them.
- Consistent package skeleton: src, tests, public entry point, README stating
  purpose and ownership.
- Vertical slices over horizontal layers where the codebase allows it.

EXECUTION RULES
- Move code atomically: update every import, build target, CI filter, and
  CODEOWNERS entry in the same commit. Never leave a half-moved state.
- For moves touching 20+ call sites: write a codemod script, run it, commit
  the script with the change.
- Tests for every touched package pass after every commit.

DELIVERABLE
- Before/after dependency graph (cycles eliminated, edges cut).
- Map of every relocation: old path → new path → reason.
- Remaining boundary violations you found but didn't fix, ranked by blast radius,
  each with a proposed fix.
```

---

## Template 3 — Hot Path & Data Access Performance

```
ROLE
You are optimizing a measured hot path. You optimize what profiling proves,
not what intuition suggests.

SCOPE
Hot path: {{endpoint/job/query/flow, e.g. POST /v1/runs, nightly metering rollup}}
Performance target: {{e.g. p95 < 200ms at 500 rps, job completes < 10 min}}
Load profile: {{current + expected 10x traffic shape if known}}

BASELINE (mandatory — no edits before this)
1. Profile the path under realistic load (CPU, allocations, wall time by span).
2. Log every query the path issues; count round trips per request.
3. Record current p50/p95/p99, throughput, error rate, and resource usage.

HUNT FOR (in priority order)
1. N+1 queries and chatty loops over IO — batch, join, or prefetch.
2. Missing/wrong indexes: EXPLAIN every query on the path; fix the plan, not
   the symptom.
3. Serial awaits that could be concurrent (independent IO fanned out).
4. Redundant work: same computation/fetch repeated per request — cache with an
   explicit invalidation story, or hoist it.
5. Payload bloat: overfetching columns/fields, unbounded result sets — add
   projection and pagination.
6. Allocation churn / serialization overhead in tight loops.

RULES
- One optimization per commit, each justified by a profiler screenshot/number.
- Re-run the load test after every change; keep a running results table.
- No caching without: TTL or invalidation rule, stampede protection, and a
  stated staleness tolerance.
- Behavior parity enforced by tests; add characterization tests around any
  logic you restructure.
- Stop when the target is met — do not keep optimizing past it.

DELIVERABLE
- Results table: baseline → after each change → final (p50/p95/p99, rps, CPU/mem).
- The one bottleneck that dominated, and how you proved it.
- Optimizations you considered and rejected, with reasons.
- New failure modes introduced (cache staleness, concurrency) and how they're mitigated.
```

---

## Template 4 — Stability Hardening (failure modes, timeouts, graceful degradation)

```
ROLE
You are hardening a service for production stability. Assume every dependency
will be slow, flaky, or down — the question is what happens when it is.

SCOPE
Target: {{service/module}}
Critical dependencies: {{DBs, queues, third-party APIs, internal services}}
SLO context: {{availability/latency objectives if defined}}

AUDIT (produce a failure-mode table before editing)
For every outbound call and every entry point, record:
- Timeout set? (missing timeout = P0 finding)
- Retry policy? Is it idempotent-safe? Bounded with backoff + jitter?
- What happens when this dependency is down: error propagated raw, request
  hangs, cascades, or degrades gracefully?
- Errors swallowed silently anywhere? (empty catch blocks = P0)
- Unbounded anything: queues, in-memory buffers, result sets, concurrency,
  request body sizes.
- Shutdown behavior: are in-flight requests drained? connections closed?

FIX PRIORITY
1. Missing timeouts on all network IO (client and server side).
2. Swallowed errors → propagate with context or handle explicitly; make every
   failure observable (structured log + metric).
3. Unbounded resources → add limits, backpressure, and rejection behavior.
4. Retries → idempotency keys where needed, exponential backoff + jitter,
   retry budgets; never retry non-idempotent writes blindly.
5. Circuit breaking / load shedding on the flakiest dependencies.
6. Graceful degradation: define per-dependency what the user sees when it's
   down (cached data, reduced feature, clear error) — implement it.

RULES
- Every fix ships with a test that simulates the failure (fault injection,
  fake slow/erroring dependency).
- No behavior change on the happy path without a stated reason.
- Tests green after every commit.

DELIVERABLE
- The failure-mode table: before → after for every dependency.
- List of P0s fixed, each with its failure-simulation test.
- Remaining known weak points, ranked by (likelihood × blast radius), with
  proposed fixes and effort estimates.
```

---

## Template 5 — Scale Readiness (statelessness, contention, headroom)

```
ROLE
You are preparing this system to handle {{Nx, e.g. 10x}} current load without
re-architecture panic. Find what breaks first and fix it in order.

SCOPE
System: {{service(s)/subsystem}}
Current scale: {{rps/jobs/tenants/data volume}}
Target scale: {{the number you're designing headroom for}}

AUDIT (rank by "what breaks first at Nx")
1. State in process memory: sessions, caches used as source of truth, local
   file writes, in-memory job state — anything that prevents running >1
   replica or kills a replica-death scenario.
2. Contention points: table hot spots, row locks, serialized critical
   sections, single-consumer queues, global mutexes.
3. Work done synchronously in request paths that could be async: emails,
   webhooks, analytics writes, fan-out — move behind a queue with an outbox
   pattern if consistency matters.
4. Data growth: unbounded tables without archival/partitioning strategy,
   queries whose cost grows with total data rather than result size.
5. Fan-out multipliers: one request → M internal calls → M×K queries. Find the
   multiplication and cap or batch it.
6. Shared-fate risks: one tenant/customer able to consume all capacity — add
   per-tenant limits/quotas/isolation where it matters.

EXECUTION RULES
- Fix in breaks-first order; after each fix, state the new estimated ceiling
  and what breaks next.
- Statelessness first: it unlocks horizontal scaling and makes everything else
  cheaper.
- Every async migration must preserve delivery semantics — state whether each
  operation is at-least-once or at-most-once and make consumers match
  (idempotent handlers for at-least-once).
- Tests green after every commit; add load/soak tests for each fixed
  bottleneck where feasible.

DELIVERABLE
- Ranked "breaks-first" list with estimated ceiling for each item, before and after.
- Changes made, in order, each with the headroom it bought.
- The next 3 bottlenecks beyond this pass, so future capacity work has a queue.
- Any place where you traded consistency for scale, stated explicitly.
```

---

## How to combine them

For a full sweep on one area, run them in this order: **1 → 2 → 4 → 3 → 5**.
Simplify first (less code to reorganize), fix boundaries second (stability and
performance work lands in the right place), harden third (so load testing in
3/5 doesn't just discover missing timeouts), then optimize and scale what's
left. Running performance work (3) before simplification (1) wastes effort
optimizing code you're about to delete.
